http://www.faqs.org/rfcs/rfc2234.html

