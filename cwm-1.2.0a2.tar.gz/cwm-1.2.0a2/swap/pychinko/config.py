####
#### point to yr local stuff
####

import sys

CWM  = "\"C:\Documents and Settings\kolovski\My Documents\mindswap\Policy Aware Web\cwm-1.0.0\cwm.py\""
CWMSOURCE = "C:\Documents and Settings\kolovski\My Documents\mindswap\Policy Aware Web\www\2000\10\swap"

# add cwm builtins source to path
#sys.path += [CWMSOURCE]
