"""Init.py

I'm not actually sure what this does.


"""

__version__ = "$Revision: 1.1 $"

__all__ = [ "string"
            ]
