Thes eare tests of te canonicalizer for NTriples, ../../cant.py

The cal*  was a problem DanC found when the canonicalizated graoh was different (I think).

The seq* was a problem I had when cant did'n't canonicalize different expressions of the same graph to the same thing.

timbl
