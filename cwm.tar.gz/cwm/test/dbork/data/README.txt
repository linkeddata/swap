These .daml files were taken from http://www.daml.ri.cmu.edu/ont/
They were found in the daml.ont registry.
These are NOT original sources.
They may NOT be copied - check teh IPR and latest verions of the originals.
They ar eincluded in this directory so as to be avialble offline as test data.

timbl
