
# Fuiles for testing RDF diference engines

#
See http://dev.w3.org/cvsweb/2004/semwalker/rdelta_diff.pl?rev=1.4&content-type=text/x-cvsweb-markup
and ../../diff.py and ../../cant.py

and aslo see tests in ../cant

