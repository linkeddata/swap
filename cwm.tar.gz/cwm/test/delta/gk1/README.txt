See http://www.ninebynine.org/RDFNotes/Swish/Intro.html#GraphDiff
