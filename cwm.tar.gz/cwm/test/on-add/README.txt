These are tests about on-add functionality in the store -- functiosn w
icj run when something is added.

