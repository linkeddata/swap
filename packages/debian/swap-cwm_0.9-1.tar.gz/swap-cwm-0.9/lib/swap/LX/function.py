



def Function:

    def isFirstOrderConnective()
