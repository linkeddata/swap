#!/usr/bin/env python


print """Setting up Cwm... (or not, in this case)"""
