#!/usr/bin/env python

import sys
sys.stderr=sys.stdout
print """Setting up Cwm... (or not, in this case)"""

for file in ('lib/*.py'):
  print """File is """ + file


# http://www.python.org/doc/1.6/dist/simple-example.html
# compare:
# 4suite installer, 
# http://easynews.dl.sourceforge.net/sourceforge/foursuite/4Suite-0.12.0a3-doc.tar.gz
